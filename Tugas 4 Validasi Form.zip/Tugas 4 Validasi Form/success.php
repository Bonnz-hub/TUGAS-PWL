<!DOCTYPE html>
<html>
<head><title>Sukses</title></head>
<body>
  <h2>Pendaftaran berhasil!</h2>
</body>
</html>
